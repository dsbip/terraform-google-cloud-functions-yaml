const functions = require('@google-cloud/functions-framework');

functions.http('render', (req, res) => res.type('text/html').send('<h1>Invoice</h1>'));
